const webpack = require('webpack');
const WebpackConfig = require('webpack-config').Config;
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const autoprefixer = require('autoprefixer');

module.exports = new WebpackConfig().extend('./webpack.config.js').merge({
	devtool: false,
	entry: './src/main.jsx',
	output: {
		path: 'dist/'
	},

	stats: {
		reasons: false
	},

	plugins: [
		new OptimizeCssAssetsPlugin({
		assetNameRegExp: /\.css$/g,
		cssProcessor: require('cssnano'),
		cssProcessorOptions: {discardComments: {removeAll: true}, reduceIdents: false},
		canPrint: true
	}),
		new webpack.optimize.DedupePlugin(),
		new webpack.optimize.OccurrenceOrderPlugin(),
		new webpack.optimize.AggressiveMergingPlugin()
	]
});

