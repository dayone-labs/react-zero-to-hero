const webpack = require('webpack');
const WebpackConfig = require('webpack-config').Config;
const ExtractTextPlugin = require("extract-text-webpack-plugin");

module.exports = new WebpackConfig().merge({

	output: { path: __dirname, filename: 'bundle.js' },

	stats: {
		colors: true
	},

	resolve: {
		extensions: ['.js', '.jsx', '.json'],
		alias: {
			'styles': __dirname + '/src/styles',
			'core': __dirname + '/src/core',
			'modules': __dirname + '/src/modules',
			'components': __dirname + '/src/components',
			'utils': __dirname + '/src/utils',
			'images': __dirname + '/src/images',
			'vendor': __dirname + '/src/vendor'
		}
	},

	module: {
		loaders: [
			{
				test: /\.jsx?$/,
				loader: 'babel-loader',
				// exclude: [/node_modules/, /\.test\.js$/],
				include: [
					/src/,
					/node_modules\/moment-range/
				],
				query: {
					presets: ['es2015', 'react', 'stage-3', 'stage-0']
				}
			}, {
				test: /\.json$/,
				exclude: /\.test\.json$/,
				loader: 'json-loader'
			},
			{
				test: /\.scss/,
				loader: ExtractTextPlugin.extract({
					fallbackLoader: 'style-loader',
					loader: [
						'css-loader',
						{
							loader: 'sass-loader',
							query: {
								sourceMap: false,
							}
						}
					],
				})
			},
			{
				test: /\.css/,
				loader: ExtractTextPlugin.extract({
					fallbackLoader: 'style-loader',
					loader: [
						'css-loader'
					],
				})
			},
			{
				test: /\.(eot|woff|woff2|png|jpg|gif|ttf|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
				loader: 'url-loader?limit=98192'
			}
		]
	},

	plugins: [
		new ExtractTextPlugin('styles.css'),
		new webpack.ProvidePlugin({
			'fetch': 'imports-loader?this=>global!exports-loader?global.fetch!whatwg-fetch'
		}),
		new webpack.NoErrorsPlugin()
	]
});
