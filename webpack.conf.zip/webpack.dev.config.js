const webpack = require('webpack');
const WebpackConfig = require('webpack-config').Config;
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const autoprefixer = require('autoprefixer');


module.exports = new WebpackConfig().extend('./webpack.config.js').merge({

	cache: true,
	devtool: '#inline-source-map',

	entry: [
		// 'webpack/hot/only-dev-server',
		'./src/main.jsx'
	],

	output: { publicPath: 'http://localhost:8080/' },

	devServer: {
		contentBase: './src',
		historyApiFallback: true,
		host: '0.0.0.0',
		port: 8080,
		proxy: {
			'/api/*': {
				target: 'http://localhost:9000',
				rewrite: function(req) {
					req.url = req.url.replace(/^\/api/, '');
				}
			},
			'/images/*': {
				target: 'http://localhost:9000'
			}
		}
	},

	stats: {
		reasons: true
	},
});

